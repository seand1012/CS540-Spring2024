class ColorLibError(Exception):
    pass
